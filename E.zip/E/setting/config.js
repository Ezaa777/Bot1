const fs = require('fs')

global.packname = 'JustinOfficial'
global.owner = "601119496612@s.whatsapp.net"
global.author = '601119496612'
global.namaowner = "JustinAndiar"
global.namabot = "Bít.ly/Aris.dev"
global.linkch = ''
global.idch = "@newsletter"

global.status = false
global.welcome = false
global.antispam = true
global.autoread = false

global.mess = {
    group: "Akses Ditolak!",
    admin: "Akses Ditolak!",
    owner: "Akses Ditolak!",
    premium: "Akses Ditolak!",
    botadmin: "Akses Ditolak!",
    private: "Akses Ditolak!"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
