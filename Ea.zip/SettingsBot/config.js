module.exports = {
  BOT_TOKEN: "7226101156:AAFnRrq94kpEivHZSq55bNJS3fNHN4ugR3w",
};
