// Aris server


const fs = require('fs')

global.owner = "601119496612"
global.footer = "pfft" 
global.status = true 
global.idSaluran = "120363417486747305@newsletter"
global.linkytb = "youtube.com/@Arisi"
global.sosmed = "@Aris"

global.lol = "";
global.mess = {
    owner: "anak kucai kau siapa"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})