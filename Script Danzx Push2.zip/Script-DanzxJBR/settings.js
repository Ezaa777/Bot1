/*

Buy Ke Tele > https://t.me/Danzx_Official

*/

const chalk = require("chalk");
const fs = require("fs");

global.owner = "6285124271621"
global.namaOwner = "DanzxJBR"
global.mode_public = true

global.linkChannel = "https://whatsapp.com/channel/0029Vb6u3GZBVJl939EMzo03"
global.idChannel = "120363372721190301@newsletter"
global.linkGrup = "https://whatsapp.com/channel/0029Vb6u3GZBVJl939EMzo03"
global.thumbnail = "https://files.catbox.moe/qvvmv9.jpg"

global.dana = "08133124186"
global.ovo = "Tidak tersedia"
global.gopay = "Tidak tersedia"
global.qris = "https://img1.pixhost.to/images/10160/660866134_jarroffc.jpg"

global.JedaPushkontak = 20000
global.JedaJpm = 10000

global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://server.ricotasya.my.id"
global.apikey = "ptla_xZZxSITraBdGqPT0Ge4nRb3HxLOZW9yX0oDM82J3" // Isi api ptla
global.capikey = "ptlc_TroIQEI72IEJRtMD2ZomZ1CV7Oeoi0ufEyWSWedle" // Isi api ptlc


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.blue(">> Update File :"), chalk.black.bgWhite(`${__filename}`))
delete require.cache[file]
require(file)
})