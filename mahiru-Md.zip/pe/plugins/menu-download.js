let handler = async (m) => {
  m.reply(`
*╭─────『 Menu Downloader 』
ᯓ .twitter  Ⓛ
ᯓ .x  Ⓛ
ᯓ .xhs  Ⓛ
ᯓ .yt5so <Url Ig/Facebook>  Ⓛ
ᯓ .aio <url>  Ⓛ
ᯓ .capcut
ᯓ .facebook <link>  Ⓛ
ᯓ .gdrive <url>  Ⓛ
ᯓ .gdrive <url>
ᯓ .igdl
ᯓ .instaaudio  Ⓛ
ᯓ .igaudio  Ⓛ
ᯓ .igst  Ⓛ
ᯓ .igstory  Ⓛ
ᯓ .dlit <platform> <url>  Ⓛ
ᯓ .mediafire <url>  Ⓛ
ᯓ .pinterest  Ⓛ
ᯓ .play
ᯓ .sfile  Ⓛ
ᯓ .spotify
ᯓ .threads
ᯓ .tiktokimg / ttimg <url>  Ⓛ
ᯓ .tiktok
ᯓ .tiktok2 <url>  Ⓛ
ᯓ .tiktokdl3 <url>  Ⓛ
ᯓ .ttmusic <link>  Ⓛ
ᯓ .ttmp3 <link>  Ⓛ
ᯓ .videy <url> Ⓟ
ᯓ .videydl <url> Ⓟ
ᯓ .wallpaper <query>
ᯓ .pindl   Ⓛ
ᯓ .pindl2  Ⓛ
ᯓ .soundcloud  Ⓛ
ᯓ .tiktokmusic <link>  Ⓛ
ᯓ .play3 <judul>  Ⓛ
ᯓ .yta <url> [128]  Ⓛ
ᯓ .ytmp3 <url> [128]  Ⓛ
ᯓ .audioyt <url> [128]  Ⓛ
ᯓ .ytmp3-2 <link youtube>  Ⓛ
ᯓ .ytmp3-3  Ⓛ
ᯓ .play2  Ⓛ
ᯓ .ytpost <link post YouTube>  Ⓛ
ᯓ .ytv <url> [360]  Ⓛ
ᯓ .ytmp4 <url> [360]  Ⓛ
ᯓ .videoyt <url> [360]  Ⓛ
ᯓ .yta2 <url>  Ⓛ
ᯓ .ytv2 <url>  Ⓛ
╰–––––––––––––––༓*
`.trim())
}
handler.command = /^menudownload$/i
handler.help = ["menudownload"]
handler.tags = ["main"]
export default handler